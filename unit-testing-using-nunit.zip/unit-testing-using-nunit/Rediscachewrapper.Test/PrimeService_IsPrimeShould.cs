using NUnit.Framework;
using Rediscachewrapper;
using System.Collections.Generic;
using System;


namespace Tests
{
    [TestFixture]
    public class PrimeService_IsPrimeShould
    {
        private readonly PrimeService _primeService;
        ICacheProvider _cacheProvider;

        public PrimeService_IsPrimeShould()
        {
            _primeService = new PrimeService();
             _cacheProvider = new RedisCacheProvider();
        }

        [Test]
        public void ReturnFalseGivenValueOf1()
        {
            var result = _primeService.IsPrime(1);         

            Assert.IsFalse(result, "1 should not be prime");
        }

        [Test]
         public void Test_SetValue()
        {
            List<person> people = new List<person>()
            {
                new person(1, "Joe", new List<Contact>()
                {
                    new Contact("1", "123456789"),
                    new Contact("2", "234567890")
                })
            };

            _cacheProvider.Set("People", people, TimeSpan.FromDays(2));
        }

        // [TestCase(-1)]
        // [TestCase(0)]
        // [TestCase(1)]
        // public void ReturnFalseGivenValuesLessThan2(int value)
        // {
        //     var result = _primeService.IsPrime(value);
        //     Assert.IsFalse(result, $"{value} should not be prime");
        // }
    }
}