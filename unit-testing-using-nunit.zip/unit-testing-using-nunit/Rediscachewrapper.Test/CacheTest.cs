using NUnit.Framework;
using Rediscachewrapper;


namespace Tests
{
    [TestFixture]
    public class CacheTest
    {
        // ICacheProvider _cacheProvider;
        // //private readonly RedisCacheProvider _primeService;

        // public CacheTest()
        // {
        //   _cacheProvider = new RedisCacheProvider();
        // }

        // [Test]
        // public void ReturnFalseGivenValueOf1()
        // {
        //     var result = _primeService.IsPrime(1); 
        //     Assert.IsFalse(result, "1 should not be prime");
        // }

        // [Test]
        //  public void Test_SetValue()
        // {
        //     List<Person> people = new List<Person>()
        //     {
        //         new Person(1, "Joe", new List<Contact>()
        //         {
        //             new Contact("1", "123456789"),
        //             new Contact("2", "234567890")
        //         })
        //     };

        //     _cacheProvider.Set("People", people);
        // }

        
    }
}