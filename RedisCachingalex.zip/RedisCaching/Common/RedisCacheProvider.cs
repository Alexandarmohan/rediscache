﻿using Configuration;
using ServiceStack.Redis;
using System;

namespace Common
{
    public class RedisCacheProvider : ICacheProvider
    {
        RedisEndpoint _endPoint;

        public RedisCacheProvider()
        {
            //_endPoint = new RedisEndpoint(RedisConfigurationManager.Config.Host, RedisConfigurationManager.Config.Port, RedisConfigurationManager.Config.Password, RedisConfigurationManager.Config.DatabaseID);
            //_endPoint = new RedisEndpoint("Alexpaiya.redis.cache.windows.net", 6380, "82UHUGh1PjCfBYfh3c4ulpfYST6oufijpLODihfThGE=", 0);
             _endPoint = new RedisEndpoint()
            {
                Host = "Alexpaiya.redis.cache.windows.net",
                Db = 0,
                ConnectTimeout = 100000,
                Password = "82UHUGh1PjCfBYfh3c4ulpfYST6oufijpLODihfThGE=",
                Port = 6380,
                Ssl = true,
                RetryTimeout = 1000000,
                ReceiveTimeout = 1000000
            };

        }

        public void Set<T>(string key, T value)
        {
            this.Set(key, value, TimeSpan.Zero);
        }

        public void Set<T>(string key, T value, TimeSpan timeout)
        {
            using (RedisClient client = new RedisClient(_endPoint))
            {
                System.Net.ServicePointManager.Expect100Continue = false;
                client.As<T>().SetValue(key, value, timeout);
            }
        }

        public T Get<T>(string key)
        {
            T result = default(T);

            using (RedisClient client = new RedisClient(_endPoint))
            {
                var wrapper = client.As<T>();

                result = wrapper.GetValue(key);
            }

            return result;
        }

        public bool Remove(string key)
        {
            bool removed = false;

            using (RedisClient client = new RedisClient(_endPoint))
            {
                removed = client.Remove(key);
            }

            return removed;
        }

        public bool IsInCache(string key)
        {
            bool isInCache = false;

            using (RedisClient client = new RedisClient(_endPoint))
            {
                isInCache = client.ContainsKey(key);
            }

            return isInCache;
        }
    }
}