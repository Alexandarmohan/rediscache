﻿using System;
using System.Collections.Generic;

namespace Rediscachewrapper
{
    public class Class1 
    {
          ICacheProvider _cacheProvider;        
        public  Class1()
        {
            _cacheProvider = new RedisCacheProvider();

            List<person> people = new List<person>()
            {
                new person(1, "Joe", new List<Contact>()
                {
                    new Contact("1", "123456789"),
                    new Contact("2", "234567890")
                })
            };

            //_cacheProvider.set("kjk",people);
            List<Contact> _contact = new List<Contact>();
            _contact = _cacheProvider.Get<List<Contact>>("People");
        }

     

        
        
       

    

    
        
    
        
    }
    
}
